# tensr
MMO board game, inspired by Go.
